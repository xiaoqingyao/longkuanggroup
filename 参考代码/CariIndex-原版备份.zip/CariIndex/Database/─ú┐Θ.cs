namespace CariIndex
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class 模块
    {
        public Guid Id { get; set; }

        [StringLength(50)]
        public string 系统 { get; set; }

        [StringLength(50)]
        public string 类别 { get; set; }

        [Required]
        [StringLength(250)]
        public string 图标 { get; set; }

        [Required]
        [StringLength(50)]
        public string 标题 { get; set; }

        public bool 显示 { get; set; }

        [Required]
        [StringLength(250)]
        public string 链接 { get; set; }

        public int W { get; set; }

        public int H { get; set; }
    }
}
