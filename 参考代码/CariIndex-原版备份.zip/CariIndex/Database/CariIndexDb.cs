﻿namespace CariIndex
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class CariIndexDb : DbContext
    {
        public CariIndexDb()
            : base("name=CariIndexDb")
        {
        }

        public virtual DbSet<模块> 模块 { get; set; }
        public virtual DbSet<默认配置> 默认配置 { get; set; }
        public virtual DbSet<用户配置> 用户配置 { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }
    }
}
