namespace CariIndex
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class 默认配置
    {
        public Guid Id { get; set; }

        [Required]
        [StringLength(100)]
        public string 单位编码 { get; set; }

        [Required]
        [StringLength(50)]
        public string 系统 { get; set; }

        public Guid 模块Id { get; set; }

        [ForeignKey("模块Id")]
        public virtual 模块 模块 { get; set; }

        public int X { get; set; }

        public int Y { get; set; }

        public int W { get; set; }

        public int H { get; set; }
    }
}
