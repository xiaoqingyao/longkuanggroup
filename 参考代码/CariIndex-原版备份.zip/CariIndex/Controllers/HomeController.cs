﻿using CariIndex.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Data.Entity;
using Newtonsoft.Json;

namespace CariIndex.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index(Guid id, string code, string system = "1")
        {
            ViewBag.UserId = id;
            ViewBag.System = system;

            using (var client = new CariIndexDb())
            {
                var userList = client.用户配置.Include(p => p.模块).Where(x => x.用户Id == id && x.模块 != null && x.系统 == system).ToList();

                if (!userList.Any())
                {
                    var defaultList = client.默认配置.Where(x => x.单位编码 == code && x.系统 == system).ToList();
                    defaultList.ForEach(x =>
                    {
                        var userConfig = new 用户配置
                        {
                            Id = Guid.NewGuid(),
                            用户Id = id,
                            系统 = x.系统,
                            模块Id = x.模块Id,
                            X = x.X,
                            Y = x.Y,
                            W = x.W,
                            H = x.H
                        };
                        client.用户配置.Add(userConfig);
                    });
                    client.SaveChanges();
                    userList = client.用户配置.Include(p => p.模块).Where(x => x.用户Id == id && x.模块 != null && x.系统 == system).ToList();
                }

                var setting = userList.Select(p => new 页面配置项
                {
                    Id = p.Id,
                    ModelId = p.模块Id,
                    UserId = p.用户Id,
                    ShowTitle = p.模块.显示,
                    Icon = p.模块.图标,
                    Title = p.模块.标题,
                    Url = p.模块.链接,
                    X = p.X,
                    Y = p.Y,
                    Width = p.W,
                    Height = p.H
                });
                ViewBag.Setting = JsonConvert.SerializeObject(setting, new JsonSerializerSettings
                {
                    ContractResolver = new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver()
                });
            }
            return View();
        }

        public ActionResult Add(Guid userId)
        {
            ViewBag.UserId = userId;
            return View();
        }

        //保存
        [HttpPost]
        public ActionResult Save(List<页面配置项> data, string system, Guid userId)
        {
            using (var client = new CariIndexDb())
            {
                if (data.Any())
                {
                    var list = client.用户配置.Where(x => x.用户Id == userId && x.系统 == system).ToList();

                    list.Where(p => data.All(l => l.Id != p.Id)).ToList().ForEach(p => client.用户配置.Remove(p));

                    data.ForEach(x =>
                    {
                        var item = list.FirstOrDefault(p => p.Id == x.Id);
                        if (item != null)
                        {
                            item.X = x.X;
                            item.Y = x.Y;
                            item.W = x.Width;
                            item.H = x.Height;
                        }
                        else
                        {
                            var newItem = new 用户配置
                            {
                                Id = x.Id,
                                用户Id = userId,
                                系统 = system,
                                模块Id = x.ModelId,
                                X = x.X,
                                Y = x.Y,
                                W = x.Width,
                                H = x.Height
                            };

                            client.用户配置.Add(newItem);
                        }
                        client.SaveChanges();
                    });
                }

            }

            return Json(data);
        }

        //选择模块
        public ActionResult GetModule(Guid userId, string system)
        {
            using (var client = new CariIndexDb())
            {
                var list = client.模块.Where(x => x.系统 == system).ToList();
                var userList = client.用户配置.Where(x => x.用户Id == userId).ToList();
                var result = list.Where(x => userList.All(l=>l.模块Id != x.Id)).GroupBy(p=>p.类别).OrderBy(p => p.Key).Select(p=> new
                {
                    Group = p.Key,
                    List = p.OrderBy(l=>l.标题).ToList(),
                }).ToList();
                return Json(result);
            }

        }
         
        //新增
        [HttpPost]
        public ActionResult AddGrid(Guid moduleId, Guid userId, string system = "1")
        {
            using (var client = new CariIndexDb())
            {
                var moduleItem = client.模块.FirstOrDefault(x => x.Id == moduleId);
                if (moduleItem != null)
                {
                    var itemMaxY = client.用户配置.Max(m => m.Y + m.H);
                    var userConfig = new 用户配置
                    {
                        Id = Guid.NewGuid(),
                        用户Id = userId,
                        系统 = system,
                        模块Id = moduleId,
                        X = 0,
                        Y = itemMaxY,
                        W = moduleItem.W,
                        H = moduleItem.H
                    };
                    client.用户配置.Add(userConfig);
                }
                client.SaveChanges();
            }
            return Json(userId);
        }
    }
}