! function (n) {
    var t = function (n) {
        this.init(n);
    };
    t.prototype = {
        init: function (t) {
            var a = {
                id: "1",
                level: 15,
                zoom: !1,
                type: ['卫星'],
                width: 0,
                height: 0,
                titleClass: "",
                contentClass: "",
                showPanorama: !1,
                showMarkPanorama: !1,
                showLabel: !1,
                mapStyle: "normal",
                icon: {},
                centerPoint: {},
                index: -1,
                animate: !1,
                points: [],
                callback: function () {}
            };
            this.currentData = null, this.opts = n.extend({}, a, t), this.render()
        },
        render: function () {
            var n = this.opts,
                t = n.id,
                a = n.centerPoint.lng,
                e = n.centerPoint.lat,
                o = n.level,
                i = new BMap.Point(a, e),
                r = this.map = new BMap.Map(t),
                l = n.mapStyle;
            r.centerAndZoom(i, o), r.setMapStyle({
                style: l
            }), this.addControl()
        },
        addControl: function () {
            var n = this.opts,
                t = this.map,
                a = n.type,
                e = n.zoom,
                o = n.showPanorama,
                i = a.length > 0 ? 40 : 20;
            if (t.addControl(new BMap.NavigationControl), t.addControl(new BMap.ScaleControl), t.addControl(new BMap.OverviewMapControl), e && t.enableScrollWheelZoom(!0), o) {
                var r = new BMap.PanoramaControl;
                r.setOffset(new BMap.Size(12, i)), t.addControl(r)
            }
            if (a.length > 0) {
                var l = this.getMapType(a);
                t.addControl(new BMap.MapTypeControl({
                    mapTypes: l
                }))
            }
            this.renderMarker()
        },
        renderMarker: function () {
            var t = this,
                a = this.opts,
                e = this.map,
                o = a.points,
                i = a.icon,
                r = a.animate,
                l = a.showLabel,
                s = a.callback;
            o.length > 0 && n.each(o, function (n, o) {
                var p = new BMap.Point(o.lng, o.lat),
                    c = new BMap.Marker(p);
                i && i.url && (c = new BMap.Marker(p, {
                    icon: new BMap.Icon(i.url, new BMap.Size(i.width, i.height))
                })), e.addOverlay(c), r && c.setAnimation(BMAP_ANIMATION_DROP), l && t.renderLabel(o), n === a.index && t.openInfoWindow(o.id), c.addEventListener("click", function () {
                    t.openInfoWindow(o.id), s && "function" == typeof s && s(o.id)
                })
            })
        },
        renderLabel: function (n) {
            var t = this.map,
                a = n.title,
                e = new BMap.Point(n.lng, n.lat),
                o = new BMap.Label(a, {
                    position: e,
                    offset: new BMap.Size(0, 0)
                });
            t.addOverlay(o)
        },
        getMapType: function (t) {
            var a = [],
                e = {
                    "地图": BMAP_NORMAL_MAP,
                    "卫星": BMAP_SATELLITE_MAP,
                    "三维": BMAP_PERSPECTIVE_MAP
                };
            return n.each(t, function (n, t) {
                t in e && a.push(e[t])
            }), a
        },
        getPosition: function (t) {
            var a = this.opts.points,
                e = null;
            return t ? a.length > 0 && n.each(a, function (n, a) {
                a.id === t && (e = a)
            }) : e = this.currentData, e
        },
        openInfoWindow: function (t) {
            var a = this,
                e = this.map,
                o = this.opts,
                i = this.getPosition(t),
                r = i.content,
                l = new BMap.Point(i.lng, i.lat),
                s = o.showMarkPanorama,
                p = "",
                c = '<div class="' + o.titleClass + '">' + i.title + "</div>";
            r.length > 0 && n.each(r, function (n, t) {
                p += '<div class="' + o.contentClass + '">' + t + "</div>"
            }), s && (c = '<div class="' + o.titleClass + '">' + i.title + '<img class="open-panorama-btn" src="img/panorama.png" style="margin-left:12px;cursor:pointer;vertical-align:sub;" title="查看全景" /></div>');
            var d = new BMap.InfoWindow(p, {
                width: o.width,
                height: o.height,
                title: c
            });
            e.openInfoWindow(d, l), setTimeout(function () {
                n("#" + o.id).find(".open-panorama-btn").on("click", function () {
                    a.openPanorama(i)
                })
            }, 30), this.currentData = i
        },
        openPanorama: function (n) {
            var t = this.map,
                a = this.opts.id,
                e = new BMap.Point(n.lng, n.lat),
                o = new BMap.Panorama(a);
            (new BMap.PanoramaService).getPanoramaByLocation(e, function (n) {
                n ? (o.setPosition(e), t.setPanorama(o)) : alert("当前位置无全景信息！")
            })
        }
    }, window.BaiduMap = t
}(jQuery);