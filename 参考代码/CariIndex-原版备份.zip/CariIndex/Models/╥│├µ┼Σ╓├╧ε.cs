﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CariIndex.Models
{
    public class 页面配置项
    {
        public Guid Id { get; set; }

        public Guid ModelId { get; set; }

        public Guid UserId { get; set; }

        public bool ShowTitle { get; set; }

        public string Icon { get; set; }

        public string Title { get; set; }

        public string Url { get; set; }

        public int X { get; set; }

        public int Y { get; set; }

        public int Width { get; set; }

        public int Height { get; set; }
    }
}